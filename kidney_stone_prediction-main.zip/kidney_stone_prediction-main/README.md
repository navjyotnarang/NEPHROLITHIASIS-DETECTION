# kidney_stone_prediction
A project to predict kidney stone from ct scan 
